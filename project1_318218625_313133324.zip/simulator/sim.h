#ifndef SIM_H
#define SIM_H

void sim(char const *argv[]);

#endif /* SIM_H */