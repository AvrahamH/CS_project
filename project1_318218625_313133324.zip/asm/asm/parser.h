#ifndef PARSER_H
#define PARSER_H

void parse_asm(char *program, char *imemin, char *dmemin);

#endif // PARSER_H