#include "parser.h"
int main(int argc, char *argv[]) {
	parse_asm(argv[1], argv[2], argv[3]);
	return 0;
}
